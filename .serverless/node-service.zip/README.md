# Node serverless

This is serverless Node.js demo on ES6+, Postgres.

## TODO

* AWS database
* Programmatic db creation
* pg pooling doesn't work
* Testing
* Return proper json for empty results
* Et.

## Install

```bash
npm i
```

## Run in development

```bash
npm run start
```

## Deploy

```bash
serverless deploy
```
